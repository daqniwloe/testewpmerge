<?php

namespace Admin;

use WP_Query;
use WPDB;

class ProductsReportController {

    public function index() {
        global $wpdb;

        echo '<div class="wrap"><h1>Relatório de Produtos Jurídicos</h1>';

        // Página atual no admin (parâmetro GET 'paged')
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 5;
        $offset = ($paged - 1) * $per_page;

        // Contar total de produtos para paginação
        $total_produtos = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->posts}
            WHERE post_type = 'product' AND post_status = 'publish'
        ");

        // Buscar produtos com limite e offset
        $produtos = $wpdb->get_results($wpdb->prepare("
            SELECT p.ID, p.post_title,
                (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_descricao_tecnica') AS descricao_tecnica,
                (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_nivel_complexidade') AS nivel_complexidade,
                (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_horas_estudo') AS horas_estudo,
                (
                    SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_order_items oi
                    INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
                    INNER JOIN {$wpdb->posts} wp ON oi.order_id = wp.ID
                    WHERE oim.meta_key = '_product_id'
                    AND oim.meta_value = p.ID
                    AND wp.post_type = 'shop_order'
                    AND wp.post_status IN ('wc-completed', 'wc-processing')
                ) AS total_pedidos
            FROM {$wpdb->posts} p
            WHERE p.post_type = 'product' AND p.post_status = 'publish'
            ORDER BY p.post_date DESC
            LIMIT %d OFFSET %d
        ", $per_page, $offset));

        // Calcular total de páginas
        $total_pages = ceil($total_produtos / $per_page);
        $base_url = admin_url('admin.php?page=aasp-custom-products');

        // Função para exibir paginação customizada
        $render_pagination = function() use ($total_pages, $paged, $base_url) {
            if ($total_pages > 1) {
                echo '<div class="tablenav"><div class="tablenav-pages">';

                // Link Anterior
                if ($paged > 1) {
                    $prev_page = $paged - 1;
                    echo '<a class="page-numbers prev" href="' . esc_url(add_query_arg('paged', $prev_page, $base_url)) . '">&laquo; Anterior</a> ';
                } else {
                    echo '<span class="page-numbers prev disabled">&laquo; Anterior</span> ';
                }

                // Página 1 sempre
                if ($paged == 1) {
                    echo '<span class="page-numbers current">1</span> ';
                } else {
                    // Link da página 1 não deve ter parâmetro paged
                    echo '<a class="page-numbers" href="' . esc_url(remove_query_arg('paged', $base_url)) . '">1</a> ';
                }

                // Páginas de 2 até total_pages
                for ($i = 2; $i <= $total_pages; $i++) {
                    if ($i == $paged) {
                        echo '<span class="page-numbers current">' . $i . '</span> ';
                    } else {
                        echo '<a class="page-numbers" href="' . esc_url(add_query_arg('paged', $i, $base_url)) . '">' . $i . '</a> ';
                    }
                }

                // Link Próximo
                if ($paged < $total_pages) {
                    $next_page = $paged + 1;
                    echo '<a class="page-numbers next" href="' . esc_url(add_query_arg('paged', $next_page, $base_url)) . '">Próximo &raquo;</a>';
                } else {
                    echo '<span class="page-numbers next disabled">Próximo &raquo;</span>';
                }

                echo '</div></div>';
            }
        };

        if ($produtos) {
            // Paginação acima da tabela
            $render_pagination();

            echo '<table class="widefat fixed striped">';
            echo '<thead><tr><th>Produto</th><th>Descrição Técnica</th><th>Nível</th><th>Horas Estudo</th><th>Pedidos</th></tr></thead><tbody>';
            foreach ($produtos as $produto) {
                echo '<tr>';
                echo '<td>' . esc_html($produto->post_title) . '</td>';
                echo '<td>' . esc_html($produto->descricao_tecnica ?: '-') . '</td>';
                echo '<td>' . esc_html($produto->nivel_complexidade ?: '-') . '</td>';
                echo '<td>' . esc_html($produto->horas_estudo ?: '-') . '</td>';
                echo '<td>' . esc_html($produto->total_pedidos) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            // Paginação abaixo da tabela
            $render_pagination();

        } else {
            echo '<p>Nenhum produto encontrado.</p>';
        }

        echo '</div>';
    }

}
