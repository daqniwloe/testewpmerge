<?php
/**
 * Plugin Name: AASP Custom Products
 * Description: Relatório de Produtos Jurídicos usando wp-emerge.
 * Version: 1.0
 * Author: Jovito
 */

add_action('plugins_loaded', function () {
    $autoload_path = ABSPATH . 'vendor/autoload.php';
    if (!file_exists($autoload_path)) {
        $autoload_path = WP_CONTENT_DIR . '/vendor/autoload.php';
    }

    if (file_exists($autoload_path)) {
        require_once $autoload_path;
    } else {
        error_log('Composer autoload.php não encontrado em: ' . $autoload_path);
        return;
    }

    if (!class_exists('WPEmerge\WPEmerge')) {
        error_log('WP Emerge não está disponível.');
        return;
    }

    $plugin = WPEmerge\WPEmerge::plugin();
    $plugin->boot([
        'controllers' => [
            'Admin\\ProductsReportController' => __DIR__ . '/app/Admin/ProductsReportController.php',
        ],
        'routes' => [
            'admin' => [
                [
                    'path' => 'aasp-custom-products',
                    'controller' => 'Admin\\ProductsReportController',
                    'action' => 'index',
                    'menu' => [
                        'page_title' => 'Relatório de Produtos Jurídicos',
                        'menu_title' => 'Relatório de Produtos Jurídicos',
                        'capability' => 'read',
                        'icon_url' => 'dashicons-chart-area',
                        'position' => 26,
                    ],
                ],
            ],
        ],
    ]);
});

add_action('admin_menu', function() {
    // Incluir o arquivo do controller
    require_once __DIR__ . '/app/Admin/ProductsReportController.php';

    add_menu_page(
        'Relatório de Produtos Jurídicos',
        'Relatório de Produtos Jurídicos',
        'read',
        'aasp-custom-products',
        function() {
            $controller = new \Admin\ProductsReportController();
            $controller->index();
        },
        'dashicons-chart-area',
        26
    );
});
