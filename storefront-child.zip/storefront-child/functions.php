<?php
// Carregar Carbon Fields
require_once ABSPATH . 'vendor/autoload.php';

use Carbon_Fields\Container;
use Carbon_Fields\Field;

add_action('after_setup_theme', function () {
    \Carbon_Fields\Carbon_Fields::boot();
});

// Campos customizados
add_action('carbon_fields_register_fields', function () {
    Container::make('post_meta', 'Informações Jurídicas')
        ->where('post_type', '=', 'product')
        ->add_fields([
            Field::make('textarea', 'descricao_tecnica', 'Descrição Técnica'),
            Field::make('select', 'nivel_complexidade', 'Nível de Complexidade')
                ->set_options([
                    'baixa' => 'Baixa',
                    'media' => 'Média',
                    'alta'  => 'Alta',
                ]),
            Field::make('text', 'horas_estudo', 'Quantidade estimada de horas para estudo')
                ->set_attribute('type', 'number')
                ->set_help_text('Informe a quantidade estimada de horas para estudo'),
        ]);
});

// Aba de Informações Jurídicas
add_filter('woocommerce_product_tabs', function ($tabs) {
    $tabs['informacoes_juridicas'] = [
        'title'    => __('Informações Jurídicas', 'storefront-child'),
        'priority' => 50,
        'callback' => 'mostrar_informacoes_juridicas',
    ];
    return $tabs;
});

// Conteúdo da aba
function mostrar_informacoes_juridicas() {
    global $product;

    if (!$product) return;

    $post_id = $product->get_id();
    $descricao = carbon_get_post_meta($post_id, 'descricao_tecnica');
    $nivel = carbon_get_post_meta($post_id, 'nivel_complexidade');
    $horas = carbon_get_post_meta($post_id, 'horas_estudo');

    echo '<h2>Informações Jurídicas</h2>';
    if ($descricao) echo '<p><strong>Descrição Técnica:</strong> ' . esc_html($descricao) . '</p>';
    if ($nivel) echo '<p><strong>Nível de Complexidade:</strong> ' . esc_html(ucfirst($nivel)) . '</p>';
    if ($horas) echo '<p><strong>Horas de Estudo:</strong> ' . esc_html($horas) . ' horas</p>';

    echo '<button id="btn-validar-produto" class="button alt" style="margin-top:10px;">
            Validar conteúdo jurídico com sistema externo
          </button>
          <div id="validacao-resultado" style="margin-top:10px;"></div>';
}

// Enfileirar JS e passar variáveis para o script
add_action('wp_enqueue_scripts', function () {
    if (is_product()) {
        global $post;

        wp_enqueue_script(
            'validacao-produto',
            get_stylesheet_directory_uri() . '/assets/validacao-produto.js',
            ['jquery'],
            '1.0',
            true
        );

        wp_localize_script('validacao-produto', 'validacaoProduto', [
            'endpoint' => 'https://mock-api.aasp.com.br/workflow/validate-product',
            'id'       => $post->ID,
            'nivel'    => carbon_get_post_meta($post->ID, 'nivel_complexidade'),
            'horas'    => carbon_get_post_meta($post->ID, 'horas_estudo')
        ]);
    }
});
