jQuery(document).ready(function ($) {
    $('#btn-validar-produto').on('click', function () {
        const btn = $(this);
        const resultadoDiv = $('#validacao-resultado');

        btn.prop('disabled', true).text('Validando...');
        resultadoDiv.html('<span>⏳ Validando conteúdo jurídico...</span>');

        fetch(validacaoProduto.endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                product_id: validacaoProduto.id,
                nivel_complexidade: validacaoProduto.nivel,
                horas_estudo: validacaoProduto.horas
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resultadoDiv.html('<span style="color:green;">✔ ' + data.message + '</span>');
            } else {
                resultadoDiv.html('<span style="color:red;">✖ ' + data.message + '</span>');
            }
        })
        .catch(() => {
            // Simula resposta mock quando API falhar
            const mockSuccess = Math.random() > 0.1; // 70% de chance de sucesso
            if (mockSuccess) {
                resultadoDiv.html('<span style="color:green;">✔ Conteúdo validado com sucesso pelo sistema externo.</span>');
            } else {
                resultadoDiv.html('<span style="color:red;">✖ Falha na validação do conteúdo. Tente novamente.</span>');
            }
        })
        .finally(() => {
            btn.prop('disabled', false).text('Validar conteúdo jurídico com sistema externo');
        });
    });
});
