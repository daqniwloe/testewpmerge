<?php
/*
Plugin Name: Carbon Fields
Plugin URI: https://carbonfields.net
Description: Custom fields library for WordPress.
Version: 3.6.9
Author: htmlburger
Author URI: https://htmlburger.com/
License: GPL2+
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Bootstrap Carbon Fields
require_once ABSPATH . 'vendor/autoload.php';

add_action( 'after_setup_theme', function () {
    \Carbon_Fields\Carbon_Fields::boot();
});
?>
